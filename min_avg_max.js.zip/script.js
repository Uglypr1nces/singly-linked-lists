class Node {
  constructor(data) {
    this.data = data;
    this.next = null;
  }
}

class SLL {
  constructor() {
    this.head = null;
  }

  addFront(value) {
    const newNode = new Node(value);
    newNode.next = this.head;
    this.head = newNode;
    return this.head;
  }

  contains(value) {
    let runner = this.head;
    while (runner) {
      if (runner.data === value) {
        return true;
      }
      runner = runner.next;
    }
    return false;
  }

  length() {
    let count = 0;
    let runner = this.head;
    while (runner) {
      count++;
      runner = runner.next;
    }
    return count;
  }

  display() {
    let values = [];
    let runner = this.head;
    while (runner) {
      values.push(runner.data);
      runner = runner.next;
    }
    return values.join(', ');
  }

  max() {
    if (!this.head) return null;
    let maxVal = this.head.data;
    let runner = this.head.next;
    while (runner) {
      if (runner.data > maxVal) {
        maxVal = runner.data;
      }
      runner = runner.next;
    }
    return maxVal;
  }

  min() {
    if (!this.head) return null;
    let minVal = this.head.data;
    let runner = this.head.next;
    while (runner) {
      if (runner.data < minVal) {
        minVal = runner.data;
      }
      runner = runner.next;
    }
    return minVal;
  }

  average() {
    if (!this.head) return null;
    let sum = 0;
    let count = 0;
    let runner = this.head;
    while (runner) {
      sum += runner.data;
      count++;
      runner = runner.next;
    }
    return sum / count;
  }
}
