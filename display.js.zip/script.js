class Node {
  constructor(data) {
    this.data = data;
    this.next = null;
  }
}

class SLL {
  constructor() {
    this.head = null;
  }

  addFront(value) {
    const newNode = new Node(value);
    newNode.next = this.head;
    this.head = newNode;
    return this.head;
  }

  contains(value) {
    let runner = this.head;
    while (runner) {
      if (runner.data === value) {
        return true;
      }
      runner = runner.next;
    }
    return false;
  }

  length() {
    let count = 0;
    let runner = this.head;
    while (runner) {
      count++;
      runner = runner.next;
    }
    return count;
  }

  display() {
    let values = [];
    let runner = this.head;
    while (runner) {
      values.push(runner.data);
      runner = runner.next;
    }
    return values.join(', ');
  }
}

